package com.accredilink.bgv.service;

import java.util.List;

import com.accredilink.bgv.pojo.BgDetails;
import com.accredilink.bgv.pojo.BgvResult;
import com.accredilink.bgv.util.ResponseObject;

public interface BgCheckService {

	public ResponseObject submitEmployeeBg();
	
	public ResponseObject submitIndividualEmployeeBg(int employeeId);
	
	public List<BgDetails> verifyEmployeeBg(String loggedInUser);
	
	public List<BgvResult> bgProofImages(int employeeId);

}
