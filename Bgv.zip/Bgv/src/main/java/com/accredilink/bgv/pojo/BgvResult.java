package com.accredilink.bgv.pojo;

import java.io.Serializable;

public class BgvResult implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int bgDateBaseId;
	private String imageData;
	private String bgvDescription;
	private String firstName;
	private String lastName;
	private String aliasType;
	private String maidenName;
	private String aliasName;

	public String getFirstName() {
		return firstName;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAliasType() {
		return aliasType;
	}

	public void setAliasType(String aliasType) {
		this.aliasType = aliasType;
	}

	public String getMaidenName() {
		return maidenName;
	}

	public void setMaidenName(String maidenName) {
		this.maidenName = maidenName;
	}

	public int getBgDateBaseId() {
		return bgDateBaseId;
	}

	public String getBgvDescription() {
		return bgvDescription;
	}

	public void setBgvDescription(String bgvDescription) {
		this.bgvDescription = bgvDescription;
	}

	public void setBgDateBaseId(int bgDateBaseId) {
		this.bgDateBaseId = bgDateBaseId;
	}

	public String getImageData() {
		return imageData;
	}

	public void setImageData(String imageData) {
		this.imageData = imageData;
	}

}
