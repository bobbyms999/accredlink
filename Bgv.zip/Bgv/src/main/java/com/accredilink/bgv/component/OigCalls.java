package com.accredilink.bgv.component;

import com.accredilink.bgv.entity.EmployeeAgency;
import com.accredilink.bgv.entity.EmployeeBgDetails;

public interface OigCalls {
	
	public EmployeeBgDetails check(EmployeeAgency employeeAgency,String field1,String filed2,String ssnNumber);

}
