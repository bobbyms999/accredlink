package com.accredilink.bgv.util;

public class StringUtil {
	
	public static boolean isNullOrEmpty(String str) {
        if(str != null && !str.isEmpty())
            return false;
        return true;
    }
	
	

}
