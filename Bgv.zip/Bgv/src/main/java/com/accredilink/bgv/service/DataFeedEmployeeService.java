package com.accredilink.bgv.service;

import java.util.List;

import com.accredilink.bgv.entity.DataFeedEmployee;

public interface DataFeedEmployeeService {

	List<DataFeedEmployee> getAllDataFeedEmployee(); 

	List<DataFeedEmployee> findAllByFirstNameAndLastName(String firstName,String lastName); 


}
