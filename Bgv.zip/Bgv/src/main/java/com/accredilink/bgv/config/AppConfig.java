package com.accredilink.bgv.config;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean
	public WebDriver newChromeDriver() {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\TECRA\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		return driver;

	}

}
