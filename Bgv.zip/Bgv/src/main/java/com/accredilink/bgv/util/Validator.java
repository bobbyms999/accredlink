package com.accredilink.bgv.util;

import java.util.Base64;

public class Validator {

	public static String validateSSN(String ssnNumber) {
		String value = ssnNumber.replace("-", "");
		return encode(value);
	}

	public static String validatePhoneNumber(String phoneNumber) {
		phoneNumber = phoneNumber.replaceAll("\\D", "");
		return phoneNumber;
	}

	public static String encode(String ssnNumber) {
		return Base64.getEncoder().encodeToString(ssnNumber.getBytes());
	}

	public static String decode(String ssnNumber) {
		return new String(Base64.getDecoder().decode(ssnNumber));
	}

}
