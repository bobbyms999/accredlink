import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-manage-employee',
  templateUrl: './manage-employee.component.html',
  styleUrls: ['./manage-employee.component.css']
})
export class ManageEmployeeComponent implements OnInit {
  editEmployeeForm: FormGroup;
  employeeList = [];
  get f() { return this.editEmployeeForm.controls; }
  employees = [
   /*  {
      firstName: 'Jeelani',
      middleName: 'Basha',
      lastName: 'Shaik',
      ssn: '123456789',
      emailId: 'jeelanshaik07@gmail.com',
      employeeId: 1
    },
    {
      firstName: 'Sai',
      middleName: '',
      lastName: 'Krishna',
      ssn: '41234878',
      emailId: 'saiKrishna@gmail.com',
      employeeId: 2
    },
    {
      firstName: 'Pavan',
      middleName: '',
      lastName: 'Kumar',
      ssn: '214587147',
      emailId: 'pavankumar@gmail.com',
      employeeId: 3
    },
    {
      firstName: 'John',
      middleName: '',
      lastName: 'Doe',
      ssn: '8757842',
      emailId: 'johndoe@gmail.com',
      employeeId: 4
    },
    {
      firstName: 'Milton',
      middleName: '',
      lastName: 'Henry',
      ssn: '987135412',
      emailId: 'henrymilton@gmail.com',
      employeeId: 5
    }, */
  ];
  employeesBackup = [];
  employeeQuery: '';
  isEdit =  false;
  currentEmployee;
  selected = [];

  onSelect({ selected }) {
    console.log('Select Event', selected, this.selected);
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  selectRow(event, row) {
    if (event.checked) {
      row.isSelected = true;
      this.selected = [...this.selected, row];
    } else {
      row.isSelected = false;
      this.selected = this.selected.filter(item => item.isSelected);
    }
    console.log(this.selected)
  }

    
    constructor(private formBuilder: FormBuilder, private apiService: ApiService, private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
    this.editEmployeeForm = this.formBuilder.group({
      ssnNumber: ['', Validators.required],
      firstName: ['', Validators.required],
      middleName: '',
      lastName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', Validators.required]
  });
    this.fetchEmployees();
  }

  fetchEmployees() {
    const sub = this.apiService.fetchEmployeeList().subscribe(data => {
      const response: any = data;
 	this.employees = response;
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees))
     /* if (response.code === 1) {
        this.employees = response.employeeList;
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees))
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      } */
    }, (error) =>  {
      this.openSnackBar('Failed to fetch employee list', 'errorSnackbar');
    }, () => {
      console.log('employee fetch complete');
    });
  }

  searchEmployee() {
    if (this.employeeQuery === '') {
      this.employees = [...this.employeesBackup];
    } else {
      const arrayToReturn = this.employeesBackup.filter(row => {
      const columns = ['firstName','lastName','emailId','ssnNumber'];
        return (columns.map(column => {
          return row[column]
        }).toString().toLowerCase().indexOf(this.employeeQuery.toString().toLowerCase())) > -1;
      });
      this.employees = arrayToReturn;
    }
  }

  editEmployee(employee) {
    console.log(employee);
    this.isEdit = true;
    this.currentEmployee = employee;
    this.editEmployeeForm = this.formBuilder.group({
      ssnNumber: [this.currentEmployee.ssnNumber, Validators.required],
      firstName: [this.currentEmployee.firstName, Validators.required],
      middleName: this.currentEmployee.middleName,
      lastName: [this.currentEmployee.lastName, Validators.required],
      emailId: [this.currentEmployee.emailId, [Validators.required, Validators.email]],
      dateOfBirth: [this.currentEmployee.dateOfBirth, Validators.required]
  });
  }

  deleteEmployee(employee) {
    const { employeeId } = employee;
  //  const newEmployeeList = this.employees.filter(e => e.ssn !== ssn);
  //  this.employees = newEmployeeList;
    const requestBody = { employeeId };
    const sub = this.apiService.deleteEmployee(employeeId).subscribe(data => {
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar(response.message, 'successSnackbar');
	 this.fetchEmployees();
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      }
    }, (error) =>  {
      this.openSnackBar('Failed to delete employee', 'errorSnackbar');
    }, () => {
      console.log('employee delete complete');
    });

  }

  saveEditing() {
    console.log(this.editEmployeeForm.value);
    this.createEmployee();
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right' });
  }

 
createEmployee() {
    console.log(this.editEmployeeForm.value);
    const requestBody = {...this.editEmployeeForm.value, employeeId: this.currentEmployee.employeeId };
    const sub = this.apiService.createEmployee(requestBody).subscribe(data => {
      console.log(data);
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar('Employee updated successfully', 'successSnackbar');
	 this.fetchEmployees();
        this.isEdit = false;
      } else if (response.code === 0) {
      this.openSnackBar('Employee update failed', 'errorSnackbar');
      }
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.message, 'errorSnackbar');
    }, () => {
      console.log('create employee success');
      this.isEdit = false;
    });
  }

}
