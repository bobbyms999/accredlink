import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  toggleType1 = 'password';
  createEmployeeForm: FormGroup;
  maxDate = new Date();
  showSpinner = false;
  get f() { return this.createEmployeeForm.controls; }

  constructor(private apiService: ApiService, private formBuilder: FormBuilder,  private snackBar: MatSnackBar) { }

  ngOnInit() {
   this.initiateForm();
  }

  initiateForm() {
    this.createEmployeeForm = this.formBuilder.group({
      ssnNumber: ['', Validators.required],
      firstName: ['', Validators.required],
      middleName: '',
      lastName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', Validators.required]
  });
  }

  showPassword1() {
    setTimeout(() => {
      this.toggleType1 = 'password';
    }, 1000);
    this.toggleType1 = 'text';
  }

  createEmployee() {
    console.log(this.createEmployeeForm.value);
    this.showSpinner = true;
    const requestBody = this.createEmployeeForm.value;
    const sub = this.apiService.createEmployee(requestBody).subscribe(data => {
      console.log(data);
      const response: any = data;
      this.openSnackBar(response.message, 'successsnNumberackbar');
      this.showSpinner = false;
      this.initiateForm();
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.message, 'errorSnackbar');
      this.showSpinner = false;
     // this.initiateForm();
    }, () => {
      console.log('create employee success');
      this.showSpinner = false;
    });
  }

  openSnackBar(message, classnNumberame) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [classnNumberame], horizontalPosition : 'right' });
  }

  resetForm() {
    this.showSpinner = false;
  /*   this.createEmployeeForm.reset();
    Object.keys(this.createEmployeeForm.controls).forEach(key => {
      this.createEmployeeForm.controls[key].setErrors(null);
    }); */
    this.initiateForm();
  }
}
