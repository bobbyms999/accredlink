package com.accredilink.bgv.util;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class ResponseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -107752139156246555L;

	private String message;
	private int code;
	
	

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
