import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpRequest, HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import { catchError, last, map, tap } from 'rxjs/operators';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-upload-employee',
  templateUrl: './upload-employee.component.html',
  styleUrls: ['./upload-employee.component.css']
})
export class UploadEmployeeComponent implements OnInit {

  employeeForm: FormGroup;
  get f() { return this.employeeForm.controls; }
  fileUploadProgress = 0;
  fileUploadComplete = false;

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className] });
  }

  constructor(private http: HttpClient, private snackBar: MatSnackBar, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.employeeForm = this.formBuilder.group({
      scheduleBg: ['', Validators.required]
  });
  }

  onClick() {
    const fileUpload = document.getElementById('fileUploadEmployee') as HTMLInputElement;
    fileUpload.onchange = () => {
      const file = fileUpload.files[0];
      this.uploadFile(file);
    };
    fileUpload.click();
  }

  uploadFile(fileToUpload) {
    const fd = new FormData();
    fd.append('file', fileToUpload);

    const req = new HttpRequest('POST', 'https://file.io', fd, {
      reportProgress: true
    });

    fileToUpload.inProgress = true;
    fileToUpload.sub = this.http.request(req).pipe(
      map(event => {
        switch (event.type) {
          case HttpEventType.UploadProgress:
            fileToUpload.progress = Math.round(event.loaded * 100 / event.total);
            console.log(fileToUpload.progress, 'progress');
            this.fileUploadProgress = fileToUpload.progress;
            console.log(this.fileUploadProgress, this.fileUploadComplete);
            break;
          case HttpEventType.Response:
            return event;
        }
      }),
      tap(message => { }),
      last(),
      catchError((error: HttpErrorResponse) => {
        fileToUpload.inProgress = false;
        fileToUpload.canRetry = true;
        this.fileUploadComplete = true;
        this.openSnackBar('File Uploaded Failed', 'errorSnackbar');
        return of(`${fileToUpload.name} upload failed.`);
      })
    ).subscribe(
      (event: any) => {
        if (typeof (event) === 'object') {
          console.log('file upload success');
          this.fileUploadProgress = 0;
          this.fileUploadComplete = false;
          this.openSnackBar('File Uploaded Successfully', 'successSnackbar');
        }
      }
    );
  }

  scheduleBg() {
    console.log(this.employeeForm.value);
  }

}
