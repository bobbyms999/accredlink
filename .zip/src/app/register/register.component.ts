import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import { ApiService } from './../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  sameAddress = false;
  registerForm: FormGroup;
  toggleType = 'password';
  isOrganization = false;
  toggleType1 = 'password';
  maxDate = new Date();
  showSpinner = false;
  submitted = false;
  get f() { return this.registerForm.controls; }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right' });
  }


  constructor(private apiService: ApiService, private formBuilder: FormBuilder, private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      ssn: ['', Validators.required],
      userName: ['', Validators.required],
      firstName: ['', Validators.required],
     /*  middleName: '', */
      lastName: ['', Validators.required],
      phoneNumber: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern(new RegExp('^[0-9]{10}$'))
      ])],
      emailId: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      rcity: ['', Validators.required],
      rstate: ['', Validators.required],
      rzipCode: ['', Validators.required],
      rcountry: ['', Validators.required],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*]){8,}'))
      ])],
      /* chouseNumber: [''],
      cstreetName: [''],
      ccity: [''],
      cstate: [''],
      czipCode: [''], */
      organizationName: ['NA', Validators.required],
      ein: ['NA', Validators.required]
  });
  }

  showPassword() {
    setTimeout(() => {
      this.toggleType = 'password';
    }, 1000);
    this.toggleType = 'text';
  }

  addressChange(event) {
    this.sameAddress = event.checked;
    if (this.sameAddress) {
      this.registerForm.patchValue({
        chouseNumber: this.registerForm.value.rhouseNumber,
        cstreetName: this.registerForm.value.rstreetName,
        ccity: this.registerForm.value.rcity,
        cstate: this.registerForm.value.rstate,
        czipCode: this.registerForm.value.rzipCode
      });
    } else {
      this.registerForm.patchValue({
        chouseNumber: '',
        cstreetName: '',
        ccity: '',
        cstate: '',
        czipCode: ''
      });
    }
    this.registerForm.markAllAsTouched();
  }

  radioChange(event) {
    console.log(this.registerForm.value);
    this.registerForm.reset();
    Object.keys(this.registerForm.controls).forEach(key => {
      this.registerForm.controls[key].setErrors(null);
    });
    if (event.value === 'individual') {
      this.isOrganization = false;
      this.registerForm.patchValue({
        organizationName: 'NA',
        ein: 0,
        ssn: '',
        firstName: '',
        lastName: '',
        dateOfBirth: '',
        phoneNumber: '',
        rcity: '',
        rstate: '',
        rzipCode: '',
        rcountry: '',
        password: '',
        userName: '',
        emailId: '',
        addressLine1: '',
        addressLine2: '',
      });
    } else if (event.value === 'organization') {
      this.isOrganization = true;

      this.registerForm.patchValue({
        organizationName: '',
        ein: '',
        dateOfBirth: new Date(),
        firstName: 'NA',
        lastName: 'NA',
        ssn: 'NA',
        phoneNumber: '',
        rcity: '',
        rstate: '',
        rzipCode: '',
        rcountry: '',
        password: '',
        userName: '',
        emailId: '',
        addressLine1: '',
        addressLine2: '',
      });
    }
  }

  registerUser() {
    let requestBody = {};
    this.showSpinner = true;
    if (this.isOrganization) {
      requestBody = {
        userName: this.registerForm.value.userName,
        companyName: this.registerForm.value.organizationName,
        ein: Number(this.registerForm.value.ein),
        type: 'organization',
        dateOfBirth: this.registerForm.value.dateOfBirth,
        password: this.registerForm.value.password,
        emailId: this.registerForm.value.emailId,
        phoneNumber: Number(this.registerForm.value.phoneNumber),
        firstName: null,
        lastName: null,
        ssnNumber: null,
        company: {
          companyName: this.registerForm.value.organizationName,
          ein: Number(this.registerForm.value.ein)
        },
        address: {
          addressLine1: this.registerForm.value.addressLine1,
          addressLine2: this.registerForm.value.addressLine2,
          city: this.registerForm.value.rcity,
          state: this.registerForm.value.rstate,
          country: this.registerForm.value.rcountry,
          zip: Number(this.registerForm.value.rzipCode),
        }
      };
    } else {
      requestBody = {
        userName: this.registerForm.value.userName,
        firstName: this.registerForm.value.firstName,
        lastName: this.registerForm.value.lastName,
        emailId: this.registerForm.value.emailId,
        ssnNumber: this.registerForm.value.ssn,
        type: 'individual',
        dateOfBirth: this.registerForm.value.dateOfBirth,
        password: this.registerForm.value.password,
        phoneNumber: Number(this.registerForm.value.phoneNumber),
        company: {
          companyName: null,
          ein: null
        },
        address: {
          addressLine1: this.registerForm.value.addressLine1,
          addressLine2: this.registerForm.value.addressLine2,
          city: this.registerForm.value.rcity,
          state: this.registerForm.value.rstate,
          country: this.registerForm.value.rcountry,
          zip: Number(this.registerForm.value.rzipCode),
        }
      };
    }
    console.log(requestBody, 'requestBody');
    const sub = this.apiService.registerUser(requestBody).subscribe(data => {
      console.log(data);
      this.openSnackBar(data.message, 'successSnackbar');
      this.router.navigateByUrl('login');
      this.showSpinner = false;
    }, () =>  {
      this.openSnackBar('Registration Failed', 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('registration success');
      this.showSpinner = false;
    });
  }

  resetForm(formDirective) {
    this.showSpinner = false;
    this.registerForm.reset();
    Object.keys(this.registerForm.controls).forEach(key => {
      this.registerForm.controls[key].setErrors(null);
    });
  }

  showPassword1() {
    setTimeout(() => {
      this.toggleType1 = 'password';
    }, 1000);
    this.toggleType1 = 'text';
  }

}
