import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const baseUrl = 'http://localhost:2020';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  registerUser(userDetails): Observable<any> {
    return this.http.post(`${baseUrl}/accredilinkdb/register`, userDetails);
  }

  loginUser(userDetails): Observable<any> {
    return this.http.post(`${baseUrl}/accredilinkdb/login`, userDetails);
  }

  sendEmailForForgotPassword(requestBody) {
    return this.http.post(`${baseUrl}/accredilinkdb/forgotPassword`, requestBody);
  }

  resetPassword(requestBody) {
    return this.http.post(`${baseUrl}/accredilinkdb/resetPassword`, requestBody);
  }

  createEmployee(requestBody) {
console.log(requestBody)
    return this.http.post(`${baseUrl}/accredilinkdb/employee/create`, requestBody);
  }

  fetchEmployeeList() {
    return this.http.get(`${baseUrl}/accredilinkdb/employee/fetchall`);
  }

  deleteEmployee(employeeId) {
    return this.http.get(`${baseUrl}/accredilinkdb/employee/delete/${employeeId}`);
  }

}

