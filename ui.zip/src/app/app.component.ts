import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth.service';
import { Router, RouterStateSnapshot } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'accrediLinkUi';
  breadcrumbs = [];
  isLogin = false;
  isRegister = false;
  hideLogout = true;
  constructor(private authService: AuthService, private router: Router) {
    //localStorage.removeItem('accrediLinkUser');
  }

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event.constructor.name === 'NavigationEnd') {
      const url = event['urlAfterRedirects'];
      let tempArray = url.split('/');
      tempArray.shift(); // remove first slash
      if (tempArray.length > 0) {
        this.breadcrumbs = [];
        console.log(tempArray);
        this.breadcrumbs.push({path: 'preEmpScreening', name: 'Home'});
        tempArray.map(item => {
          /* if (item === 'preEmpScreening') {
            this.breadcrumbs.push({path: 'preEmpScreening', name: 'Pre-Employment Screening'})
          } */
          if (item === 'createEmployee') {
            this.breadcrumbs.push({path: 'preEmpScreening/pmlanding/createEmployee', name: 'Create Employee'})
          }
          if (item === 'manageEmployee') {
            this.breadcrumbs.push({path: 'preEmpScreening/pmlanding/manageEmployee', name: 'Manage Employee'})
          }
          if (item === 'monthlyEmpScreening') {
            this.breadcrumbs.push({path: 'monthlyEmpScreening', name: 'Monthly Employee Screening'});
          }
          if (item === 'uploadEmployee') {
            this.breadcrumbs.push({path: 'preEmpScreening/uploadEmployee', name: 'Upload Employee'})
          }
          if (item === 'uploadAlias') {
            this.breadcrumbs.push({path: 'preEmpScreening/uploadAlias', name: 'Upload Static Alias'});
          }
        });
      }
      if (tempArray.length === 1) {
        if (tempArray.indexOf('login') > -1) {
          tempArray = [];
          this.breadcrumbs = [];
          this.isLogin = true;
          this.isRegister = false;
          this.hideLogout = true;
        } 
        if (tempArray.indexOf('register') > -1) {
          tempArray = [];
          this.breadcrumbs = [];
          this.isRegister = true;
          this.isLogin = false;
          this.hideLogout = true;
        } 
        if (tempArray.indexOf('resetPassword') > -1) {
          tempArray = [];
          this.breadcrumbs = [];
          this.isRegister = true;
          this.isLogin = false;
          this.hideLogout = true;
        }
      }
    }
    });
  }



  navigateRoute() {
    this.authService.getLoginState() ? this.router.navigateByUrl('landing') : this.router.navigateByUrl('');
  }

  logout() {
    this.authService.removeLoginState();
    this.router.navigateByUrl('/login');
  }
}
