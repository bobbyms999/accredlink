import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import { ApiService } from './../api.service';
import { AuthService } from './../auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  resetPasswordForm: FormGroup;
  toggleType1 = 'password';
  toggleType2 = 'password';
  showForgotPasswordField = false;
  notSame = false;
  get f() { return this.resetPasswordForm.controls; }

  constructor(
    private apiService: ApiService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private authService: AuthService,
    private snackBar: MatSnackBar,
    private router: Router
  ) { }

  ngOnInit() {
    this.resetPasswordForm = this.formBuilder.group({
      password1: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*]){8,}'))
      ])],
      password2: ['', Validators.compose([
        Validators.required,
        Validators.pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])'))
      ])],
  });
  }

  showPassword(num) {
    if (num === 1) {
      setTimeout(() => {
        this.toggleType1 = 'password';
      }, 1000);
      this.toggleType1 = 'text';
    } else if (num === 2) {
      setTimeout(() => {
        this.toggleType2 = 'password';
      }, 1000);
      this.toggleType2 = 'text';
    }
  }

  resetPassword() {
    const notSame = this.checkSame();
    if (notSame) {
      this.openSnackBar('Passwords do not match', 'errorSnackbar');
    } else {
     const requestBody = { password: this.resetPasswordForm.value.password1, token: this.route.snapshot.queryParamMap.get('token'), emailId: this.route.snapshot.queryParamMap.get('email')};
     const sub = this.apiService.resetPassword(requestBody).subscribe(data => {
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar(response.message, 'successSnackbar');
        this.router.navigateByUrl('login');
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      }
    }, () =>  {
      this.openSnackBar('Reset Password Failed', 'errorSnackbar');
    }, () => {
      console.log('Password reset complete');
    });

    }
  }

  checkSame() {
    const p1 = this.resetPasswordForm.value.password1;
    const p2 = this.resetPasswordForm.value.password2;
    if (p1 !== p2) {
      console.log('not same');
      this.notSame = true;
    } else {
      this.notSame = false;
    }
    return this.notSame;
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right' , verticalPosition: 'top' });
  }


}
