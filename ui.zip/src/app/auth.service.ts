import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  isLoggedIn = false;

  constructor() { }

  setLoginState = () =>  {
    this.isLoggedIn = true;
    localStorage.setItem('accrediLinkUser', 'admin');
  }

  removeLoginState = () =>  {
    this.isLoggedIn = false;
    localStorage.removeItem('accrediLinkUser');
  }

  getLoginState() {
    if (this.isLoggedIn) {
      return true;
    } else if (localStorage.getItem('accrediLinkUser')) {
      return true;
    } else {
     // console.log('user not found');
      return false;
    }
  }
}
