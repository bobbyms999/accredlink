import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const baseUrl = 'http://localhost:2020';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  registerUser(userDetails): Observable<any> {
    return this.http.post(`${baseUrl}/accredilink/user/register`, userDetails);
  }

  loginUser(userDetails): Observable<any> {
    return this.http.post(`${baseUrl}/accredilink/user/login`, userDetails);
  }

  sendEmailForForgotPassword(requestBody) {
    return this.http.post(`${baseUrl}/accredilink/user/forgotpassword`, requestBody);
  }

  resetPassword(requestBody) {
    return this.http.post(`${baseUrl}/accredilink/user/resetpassword`, requestBody);
  }

  createEmployee(requestBody, loginId) {
    return this.http.post(`${baseUrl}/accredilink/employee/${loginId}/create`, requestBody);
  }

  updateEmployee(requestBody,loginId) {
    return this.http.post(`${baseUrl}/accredilink/employee/${loginId}/update`, requestBody);
  }

  fetchEmployeeList(loginId) {
    return this.http.get(`${baseUrl}/accredilink/employee/${loginId}/fetchallemployees`);
  }

  deleteEmployee(employeeId,loginId) {
    return this.http.get(`${baseUrl}/accredilink/employee/${loginId}/delete/${employeeId}`);
  }

  fetchAgencyList() {
    return this.http.get(`${baseUrl}/accredilink/employee/fetchallagencies`);
  }

  fetchDesignationList() {
    return this.http.get(`${baseUrl}/accredilink/employee/fetchalldisciplines`);
  }

  fetchEmployeeBgList(loginId) {
    return this.http.get(`${baseUrl}/accredilink/submit/${loginId}/bgverify`);
  }

  fetchBgvProof(employeeId) {
   return this.http.get(`${baseUrl}/accredilink/submit/bgproof/${employeeId}`);
   // return this.http.get(`assets/bgvProof.json`);
  }

  submitBg() {
    return this.http.get(`${baseUrl}/accredilink/submit/bgsubmit`);
  }

  submitSpecificBg(employeeId) {
    return this.http.get(`${baseUrl}/accredilink/submit/bgsubmit/${employeeId}`);
  }

}

