import { Component, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import {RecaptchaComponent} from 'ng-recaptcha';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import { ApiService } from './../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  @ViewChild('recaptchaRef',  {static: false})
  recaptchaRef: RecaptchaComponent;
  sameAddress = false;
  registerForm: FormGroup;
  captchaForm: FormGroup;
  toggleType = 'password';
  isOrganization = true;
  toggleType1 = 'password';
  toggleType2 = 'password';
  maxDate = new Date();
  showSpinner = false;
  submitted = false;
  captchaRadio = false;
  captchaCheckbox = null;
  isLogoAvailable = false;
  logoUrl = null;
  logoBase64 = null;
  get f() { return this.registerForm.controls; }


  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right', verticalPosition: 'top'  });
  }

  ssnAppend(event) {
    let value = event.target.value;
    if (value.length === 3) {
      value = value + '-';
      this.registerForm.patchValue({ssn: value});
    } else if (value.length === 6) {
      value = value + '-';
      this.registerForm.patchValue({ssn: value});
    }
  }

  phoneAppend(event) {
    let value = event.target.value;
    if (value.length === 1) {
      value = '(' + value;
      this.registerForm.patchValue({phoneNumber: value});
    } else if (value.length === 4) {
      value = value + ')-';
      this.registerForm.patchValue({phoneNumber: value});
    } else if (value.length === 9) {
      value = value + '-';
      this.registerForm.patchValue({phoneNumber: value});
    }
  }

  checkPassword(event) {
    const value = event.target.value;
    if (value !== this.registerForm.value.password1) {
      this.registerForm.controls['password2'].setErrors({noMatch: true});
    }
  }
  constructor(private apiService: ApiService, private formBuilder: FormBuilder, private snackBar: MatSnackBar, private router: Router, private sanitizer: DomSanitizer) { }

  resolved(event) {
    console.log(event);
    this.captchaCheckbox = event;
  }

  
  ngOnInit() {
  
    this.registerForm = this.formBuilder.group({
      ssn: ['123-56-8790', Validators.compose([
        Validators.required,
        Validators.maxLength(12),
        Validators.pattern(new RegExp('^[0-9]{3}\-?[0-9]{2}\-?[0-9]{4}$'))
      ])],
      userName: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(12),
        Validators.pattern(new RegExp('^[a-zA-Z0-9_]*$'))
      ])],
      firstName: ['abc', Validators.required],
      middleName: '',
      lastName: ['def', Validators.required],
      phoneNumber: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(14),
    //    Validators.pattern(new RegExp('^[0-9]*$'))
      Validators.pattern(new RegExp('^([\(])[0-9]{3}([\)])\-?[0-9]{3}\-?[0-9]{4}$')),
      ])],
     // emailId: ['', [Validators.required, Validators.email]],
     emailId: ['', Validators.compose([
      Validators.required,
      Validators.email,
      Validators.pattern(new RegExp('\.com'))
    ])],
      dateOfBirth: [new Date(), Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      rcity: ['', Validators.required],
      rstate: ['', Validators.required],
      rzipCode: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(5),
        Validators.pattern(new RegExp('^[0-9]*$'))
      ])],
      rcountry: [{value: 'USA', disabled: true}, Validators.required],
      password1: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*]){8,}'))
      ])],
      password2: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*]){8,}'))
      ])],
      /* chouseNumber: [''],
      cstreetName: [''],
      ccity: [''],
      cstate: [''],
      czipCode: [''], */
      organizationName: ['', Validators.required],
      ein: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern(new RegExp('^[0-9]*$'))
      ])],
     // recaptcha: ['', Validators.required]
  });
  }

  showPassword() {
    setTimeout(() => {
      this.toggleType = 'password';
    }, 1000);
    this.toggleType = 'text';
  }

  addressChange(event) {
    this.sameAddress = event.checked;
    if (this.sameAddress) {
      this.registerForm.patchValue({
        chouseNumber: this.registerForm.value.rhouseNumber,
        cstreetName: this.registerForm.value.rstreetName,
        ccity: this.registerForm.value.rcity,
        cstate: this.registerForm.value.rstate,
        czipCode: this.registerForm.value.rzipCode
      });
    } else {
      this.registerForm.patchValue({
        chouseNumber: '',
        cstreetName: '',
        ccity: '',
        cstate: '',
        czipCode: ''
      });
    }
    this.registerForm.markAllAsTouched();
  }

  print() {
    console.log(this.registerForm);
  }



  checkboxChange(event) {
  //  console.log(event);
    const isChecked = event.checked;
    this.captchaCheckbox = isChecked;
    //console.log(this.captchaCheckbox)
  }

  radioChange(event) {
    console.log(this.registerForm);
    this.registerForm.reset();
    Object.keys(this.registerForm.controls).forEach(key => {
      this.registerForm.controls[key].setErrors(null);
    });
    this.recaptchaRef.reset();
    if (event.value === 'individual') {
      this.isOrganization = false;
      this.registerForm.patchValue({
        organizationName: 'NA',
        ein: 9876543210,
        ssn: '',
        firstName: '',
        lastName: '',
        dateOfBirth: '',
        phoneNumber: '',
        rcity: '',
        rstate: '',
        rzipCode: '',
        rcountry: '',
        password: '',
        userName: '',
        emailId: '',
        addressLine1: '',
        addressLine2: '',
        middleName: ''
      });
    } else if (event.value === 'organization') {
      this.isOrganization = true;

      this.registerForm.patchValue({
        organizationName: '',
        ein: '',
        dateOfBirth: new Date(),
        firstName: 'NA',
        lastName: 'NA',
        ssn: '999-99-9999',
        phoneNumber: '',
        rcity: '',
        rstate: '',
        rzipCode: '',
        rcountry: '',
        password: '',
        userName: '',
        emailId: '',
        addressLine1: '',
        addressLine2: '',
        middleName: 'NA'
      });
    }
  }

  registerUser() {
    let requestBody = {};
    this.showSpinner = true;
    if (this.isOrganization) {
      requestBody = {
        userName: this.registerForm.value.userName,
        companyName: this.registerForm.value.organizationName,
        ein: Number(this.registerForm.value.ein),
        type: 'agency',
        dateOfBirth: this.registerForm.value.dateOfBirth,
        password: this.registerForm.value.password1,
        emailId: this.registerForm.value.emailId,
        phoneNumber: this.registerForm.value.phoneNumber,
        firstName: null,
        lastName: null,
        ssnNumber: null,
        agency: {
          agencyName: this.registerForm.value.organizationName,
		  agencyLogo: this.logoBase64,
          ein: Number(this.registerForm.value.ein)
        },
        address: {
          addressLine1: this.registerForm.value.addressLine1,
          addressLine2: this.registerForm.value.addressLine2,
          city: this.registerForm.value.rcity,
          state: this.registerForm.value.rstate,
          country: this.registerForm.value.rcountry,
          zip: Number(this.registerForm.value.rzipCode),
        },
        middleName: null
      };
    } else {
      requestBody = {
        userName: this.registerForm.value.userName,
        firstName: this.registerForm.value.firstName,
        lastName: this.registerForm.value.lastName,
        emailId: this.registerForm.value.emailId,
        ssnNumber: this.registerForm.value.ssn,
        type: 'individual',
        dateOfBirth: this.registerForm.value.dateOfBirth,
        password: this.registerForm.value.password1,
        phoneNumber: Number(this.registerForm.value.phoneNumber),
        agency: {
          agencyName: null,
          ein: null
        },
        address: {
          addressLine1: this.registerForm.value.addressLine1,
          addressLine2: this.registerForm.value.addressLine2,
          city: this.registerForm.value.rcity,
          state: this.registerForm.value.rstate,
          country: this.registerForm.value.rcountry,
          zip: Number(this.registerForm.value.rzipCode),
        },
        middleName: this.registerForm.value.middleName
      };
    }
    console.log(requestBody, 'requestBody');
    const sub = this.apiService.registerUser(requestBody).subscribe(data => {
      console.log(data);
      this.openSnackBar(data.message, 'successSnackbar');
      this.router.navigateByUrl('login');
      this.showSpinner = false;
      this.recaptchaRef.reset();
    }, (error) =>  {
      console.log(error, 'error from register');
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
      this.recaptchaRef.reset();
    }, () => {
      console.log('registration success');
      this.showSpinner = false;
      this.recaptchaRef.reset();
    });
  }

  resetForm(formDirective) {
    this.showSpinner = false;
    this.registerForm.reset();
    Object.keys(this.registerForm.controls).forEach(key => {
      this.registerForm.controls[key].setErrors(null);
    });
    this.recaptchaRef.reset();
  }

  showPassword1() {
    setTimeout(() => {
      this.toggleType1 = 'password';
    }, 1000);
    this.toggleType1 = 'text';
  }

  showPassword2() {
    setTimeout(() => {
      this.toggleType2 = 'password';
    }, 1000);
    this.toggleType2 = 'text';
  }


  uploadLogo() {
    const fileUpload = document.getElementById('fileUploadLogo') as HTMLInputElement;
    fileUpload.onchange = () => {
      const file = fileUpload.files[0];
      const reader = new FileReader();
      let baseString;
      reader.onloadend = () => {
          baseString = reader.result;
          if (baseString.length) {
            this.isLogoAvailable = true;
            this.logoBase64 = baseString;
            this.logoUrl = this.sanitizer.bypassSecurityTrustUrl(baseString);
          }
      };
      reader.readAsDataURL(file);
      fileUpload.value = '';
    };
    fileUpload.click();
  }

  removeLogo() {
    this.logoUrl = null;
    this.isLogoAvailable = false;
    this.logoBase64 = null;
  }
}
