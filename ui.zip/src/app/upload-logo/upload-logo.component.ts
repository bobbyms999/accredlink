import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-logo',
  templateUrl: './upload-logo.component.html',
  styleUrls: ['./upload-logo.component.css']
})
export class UploadLogoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
