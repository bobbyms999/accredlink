import { Component, OnInit, Inject } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
@Component({
  selector: 'app-view-bg',
  templateUrl: './view-bg.component.html',
  styleUrls: ['./view-bg.component.css']
})
export class ViewBgComponent implements OnInit {

  /*  employees = [
    {employeeId:611926,firstName:"Patricia",lastName:"ACOSTA",middleName:'Dennis',emailId:'dennis@123',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:new Date(),bgvResult:"PASS"},
    {employeeId:789,firstName:"Patricia",lastName:"ACOSTA",middleName:'Jcob',emailId:null,ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-12",bgvResult:"PASS"},
    {employeeId:611926,firstName:"Patricia",lastName:"ACOSTA",middleName:'Dennis',emailId:'dennis@123',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-13",bgvResult:"PASS"},
    {employeeId:789,firstName:"Patricia",lastName:"ACOSTA",middleName:'Jcob',emailId:'thomas@78',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-14",bgvResult:"PASS"},
    {employeeId:611926,firstName:"Patricia",lastName:"ACOSTA",middleName:'Dennis',emailId:'dennis@123',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-15",bgvResult:"PASS"},
    {employeeId:789,firstName:"Patricia",lastName:"ACOSTA",middleName:'Jcob',emailId:'thomas@78',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-16",bgvResult:"PASS"},
    {employeeId:611926,firstName:"Patricia",lastName:"ACOSTA",middleName:'Dennis',emailId:'dennis@123',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-17",bgvResult:"PASS"},
    {employeeId:789,firstName:"Patricia",lastName:"ACOSTA",middleName:'Jcob',emailId:'thomas@78',ssnNumber:"835415922",agencyName:"Caprock Home Health Services",bgvDate:"2019-12-18",bgvResult:"PASS"},
  ]; */
  employees = [];
  employeesBackup = [];
  employeeQuery: '';
  startDate = null;
  endDate = null;

  constructor(private apiService: ApiService,  private snackBar: MatSnackBar, public dialog: MatDialog) {

   }

  ngOnInit() {
    this.fetchEmployees();
    this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
  }

  dateFilter() {
    const startDate = new Date(this.startDate);
    const endDate = new Date(this.endDate);
    endDate.setDate(endDate.getDate() + 1);
    const resultProductData = this.employeesBackup.filter((employee)  => {
      const date = new Date(employee.bgvDate);
      return (date >= startDate && date <= endDate);
    });
    this.employees = [...resultProductData];
  }

  clearFilter() {
    this.startDate = null;
    this.endDate = null;
    this.employees = [...this.employeesBackup];
  }

  searchEmployee() {
    if (this.employeeQuery === '') {
      this.employees = [...this.employeesBackup];
    } else {
      const arrayToReturn = this.employeesBackup.filter(row => {
      const columns = ['firstName','lastName','emailId','ssnNumber', 'agencyName'];
        return (columns.map(column => {
          return row[column]
        }).toString().toLowerCase().indexOf(this.employeeQuery.toString().toLowerCase())) > -1;
      });
      this.employees = arrayToReturn;
    }
  }


  fetchEmployees() {
	 const loginId = localStorage.getItem('accrLoginId');
    const sub = this.apiService.fetchEmployeeBgList(loginId).subscribe(data => {
      const response: any = data;
      let employees = [];
      if (response.length) {
		  employees = response.filter(item => item.active !== 'NOT_STARTED');
      this.employees = employees;
    //this.employees = response;
       // employees = response.filter(item => item.active === 'S');
       // this.employees = employees;
        /* this.employees = this.employees.map(employee => {
          if (employee.agency.length) {
            employee['agencyName'] = employee.agency[0].agencyName;
          } else {
            employee['agencyName'] = '';
          }
          return employee;
        }) */
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
      //   console.log(this.employees, 'employeelist');
      } else {
        this.employees = []
        this.employeesBackup = []
      }
    }, (error) =>  {
      console.log(error);
    //  this.openSnackBar('Server error', 'errorSnackbar');
    }, () => {
      console.log('employee fetch complete');

    });
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition : 'right', verticalPosition: 'top'  });
  }

	
  viewBgvProof(selectedEmployee) {
    this.apiService.fetchBgvProof(selectedEmployee.employeeId).subscribe(response => {
      this.openDialog(response, selectedEmployee);
    });
  }

  startDateChange(event) {
    this.startDate = event.target.value;
  }

  endDateChange(event) {
    this.endDate = event.target.value;
  }

  openDialog(response, selectedEmployee): void {
    const dialogRef = this.dialog.open(ViewProofDialog, {
      width: '90vw',
      maxWidth: '90vw',
      minHeight: '90vh',
      data: {response, selectedEmployee},
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        //this.deleteEmployee(row);
      }
    });
  }

}



@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: './viewBgProof.html',
  styles: [
    `.listItem:hover {
      background: rgba(0,0,0,0.05);
      cursor: pointer;
    }
    .selected {
      background: rgba(0,0,0,0.05);
    }`
  ]
})

export class ViewProofDialog implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<ViewProofDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private sanitizer: DomSanitizer, private apiService: ApiService) {}

    currentImageUrl = null;
    currentImageName = null;
    currentBgvDescription = '';
  onNoClick(): void {
    this.dialogRef.close();
  }

  selectImage(image) {
    this.currentImageUrl = this.sanitizer.bypassSecurityTrustUrl('data:image/bmp;base64,' + image.imageData);
    this.currentImageName = image.bgDateBaseId;
    this.currentBgvDescription = image.bgvDescription;
  }

  ngOnInit() {
    this.currentImageUrl = this.sanitizer.bypassSecurityTrustUrl('data:image/bmp;base64,' + this.data.response[0].imageData);
	console.log(this.currentImageUrl);
    this.currentImageName = this.data.response[0].bgDateBaseId;
    this.currentBgvDescription = this.data.response[0].bgvDescription;
  }

  downloadFile(bgId) {
    //console.log(bgId, typeof(bgId));
    let dbName = '';
    if (1 === Number(bgId)) {
      dbName = 'National OIG';
    } else if (2 === Number(bgId)) {
      dbName = 'Tx OIG';
    } else if (3 === Number(bgId)) {
      dbName = 'Dads EMR';
    }
    const image = this.currentImageUrl.changingThisBreaksApplicationSecurity.slice('data:image/bmp;base64,'.length);

    this.FileDownload(image, 'image/png', dbName)
    .then(() => console.log('download successful.'))
    .catch((err) => console.error('download error: ', err));
  }

 FileDownload = (base64, contentType, name) => {
    return new Promise((resolve, reject) => {
      const url = `data:${contentType};base64,${base64}`;
      fetch(url)
        .then(res => res.blob())
        .catch(err => reject(err))
        .then(blob => {
          this.downloadBlob(blob, name);
          resolve();
        })
        .catch(err => reject(err));
    });
  }

  downloadBlob = (blob, name) => {
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

}
