import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  toggleType1 = 'text';
  createEmployeeForm: FormGroup;
  maxDate = new Date();
  showSpinner = false;
  agencyId = null;
  designationId = null;
  get f() { return this.createEmployeeForm.controls; }
  myModel = '';
  ssnMask = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  agencyList = [];
  designationList = [];

  constructor(private apiService: ApiService, private formBuilder: FormBuilder,  private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
   this.initiateForm();
   this.fetchDesignationList();
  }

  ssnAppend(event) {
    let value = event.target.value;
    if (value.length === 3) {
      value = value + '-';
      this.createEmployeeForm.patchValue({ssnNumber: value});
    } else if (value.length === 6) {
      value = value + '-';
      this.createEmployeeForm.patchValue({ssnNumber: value});
    }
  }
 
  initiateForm() {
    this.createEmployeeForm = this.formBuilder.group({
      ssnNumber: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(12),
        Validators.pattern(new RegExp('^[0-9]{3}\-?[0-9]{2}\-?[0-9]{4}$'))
      ])],
      firstName: ['', Validators.required],
      middleName: '',
      maidenName: '',
      lastName: ['', Validators.required],
      alias : [''],
     emailId: ['', Validators.compose([
      Validators.email,
      Validators.pattern(new RegExp('\.com'))
    ])],
      dateOfBirth: ['', Validators.required],
      agencyId: [{value: localStorage.getItem('accrAgencyName'), disabled: true}, Validators.required],
      designationId: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      rcity: ['', Validators.required],
      rstate: ['', Validators.required],
      rzipCode: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(5),
        Validators.pattern(new RegExp('^[0-9]*$'))
      ])],
      rcountry: ['', Validators.compose([
        Validators.required,
        Validators.pattern(new RegExp('^[a-zA-Z]*$'))
      ])],
  });
  }

  fetchAgencyList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchAgencyList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.agencyList = response;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  fetchDesignationList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchDesignationList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.designationList = response;
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  showPassword1() {
    setTimeout(() => {
      this.toggleType1 = 'password';
    }, 1000);
    this.toggleType1 = 'text';
  }

  createEmployee() {
    console.log(this.createEmployeeForm.value);
    this.showSpinner = true;
    const requestBody = {...this.createEmployeeForm.value};
    requestBody.aliasSpecific =  this.createEmployeeForm.value.alias;
    //requestBody.agency = [{agencyId: this.agencyId}];
    requestBody.agency = [{agencyId: localStorage.getItem('accrAgencyId')}];
    requestBody.discipline =  {disciplineId: this.designationId ,disciplineValue:this.designationList.filter(item=> item.disciplineId===this.designationId)[0].disciplineValue};
    requestBody.address = {
      addressLine1: this.createEmployeeForm.value.addressLine1,
      addressLine2: this.createEmployeeForm.value.addressLine2,
      city: this.createEmployeeForm.value.rcity,
      state: this.createEmployeeForm.value.rstate,
      country: this.createEmployeeForm.value.rcountry,
      zip: Number(this.createEmployeeForm.value.rzipCode),
    },
    delete requestBody.agencyId;
    delete requestBody.designationId;
    delete requestBody.addressLine1;
    delete requestBody.addressLine2;
    delete requestBody.rcity;
    delete requestBody.rstate;
    delete requestBody.rcountry;
    delete requestBody.rzipCode;
   // console.log(requestBody);

    const request = {
      bgStatus: 'NOT_STARTED',
      employeeAgencyPk: {
        agency: {
          // agencyName: 'Caprock Home Health Services',
          agencyName: localStorage.getItem('accrAgencyName')
        },
        employee: {
          address: {
            addressLine1: this.createEmployeeForm.value.addressLine1,
            addressLine2: this.createEmployeeForm.value.addressLine2,
            city: this.createEmployeeForm.value.rcity,
            state: this.createEmployeeForm.value.rstate,
            country: this.createEmployeeForm.value.rcountry,
            zip: Number(this.createEmployeeForm.value.rzipCode),
          },
          discipline: {
            disciplineId: this.designationId,
            disciplineValue: this.designationList.filter(item => item.disciplineId === this.designationId)[0].disciplineValue
          },
          aliasSpecific: this.createEmployeeForm.value.alias,
          dateOfBirth: this.createEmployeeForm.value.dateOfBirth,
          emailId: this.createEmployeeForm.value.emailId,
          firstName: this.createEmployeeForm.value.firstName,
          lastName: this.createEmployeeForm.value.lastName,
          maidenName: this.createEmployeeForm.value.maidenName,
          middleName: this.createEmployeeForm.value.middleName,
          ssnNumber: this.createEmployeeForm.value.ssnNumber,
        }
      }
    };
    console.log(request, 'request');
    const loginId = localStorage.getItem('accrLoginId');
    const sub = this.apiService.createEmployee(request, loginId).subscribe(data => {
      console.log(data);
      const response: any = data;
      this.openSnackBar(response.message, 'successSnackbar');
      this.showSpinner = false;
      this.initiateForm();
      this.router.navigateByUrl('preEmpScreening');
    }, (error) =>  {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
     // this.initiateForm();
    }, () => {
      console.log('create employee success');
      this.showSpinner = false;
    });
  }

  openSnackBar(message, classnNumberame) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [classnNumberame], horizontalPosition : 'right', verticalPosition: 'top'  });
  }

  resetForm() {
    this.showSpinner = false;
    this.agencyId = null;
    this.designationId = null;
    this.initiateForm();
  }

  agencyChange(event) {
    this.agencyId = event;
  }

  designationChange(event) {
    this.designationId = event;
  }

}
