import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ApiService } from './../../api.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { viewClassName } from '@angular/compiler';

@Component({
  selector: 'app-manage-employee',
  templateUrl: './manage-employee.component.html',
  styleUrls: ['./manage-employee.component.css']
})
export class ManageEmployeeComponent implements OnInit {
  @ViewChild('empGrid', {static: false}) empGrid;
  editEmployeeForm: FormGroup;
  employeeList = [];
  canDelete = false;
  showSpinner = false;
  agencyId = null;
  designationId = null;
  designationList = [];
  agencyList = [];
  isSubmitDisabled = false;
  currentAgencyName = null;
  /*  agencyList = [
     {agencyId: 12, agencyName: 'Apollo'},
     {agencyId: 34, agencyName: 'MRF'},
     {agencyId: 56, agencyName: 'Michellin'},
     {agencyId: 78, agencyName: 'Ceat'}
   ];*/

    /*  designationList = [
      {disciplineId: 121, disciplineValue: 'Hero'},
      {disciplineId: 343, disciplineValue: 'Super-Hero'},
      {disciplineId: 565, disciplineValue: 'Villian'},
      {disciplineId: 787, disciplineValue: 'Super-Villian'},
    ];  */ 

  get f() { return this.editEmployeeForm.controls; }
  maxDate = new Date();
  employees = [];
   /*    employees = [
          {
      firstName: 'Jeelani',
      middleName: 'Basha',
      lastName: 'Shaik',
      maidenName: '1687988',
      ssnNumber: '123456789',
      emailId: 'jeelanshaik07@gmail.com',
      employeeId: 1,
      alias: 'jillu',
      agency: [{agencyName:'Caprock', agencyId: 1}],
      discipline: {disciplineValue:'Hero', disciplineId: 121},
      dateOfBirth: new Date(),
      address : {addressLine1: '16/165-232', addressLine2: 'anjali Nagar', city: 'Guntakal', state: 'AP', country: 'india', zip: 515801}
    },
    {
      firstName: 'Sai',
      middleName: 'Vempalli',
      lastName: 'Krishna',
      ssnNumber: '41234878',
      maidenName: 'qwer12345',
      alias: 'dubbodu',
      emailId: 'saiKrishna@gmail.com',
      employeeId: 2,
      agency: [{agencyName:'Caprock', agencyId: 1}],
      discipline: {disciplineValue:'Super-Hero', disciplineId: 343},
      dateOfBirth: new Date(),
      address : {addressLine1: '13/789-146', addressLine2: 'Bhagya Nagar', city: 'Anantapur', state: 'TN', country: 'mexico', zip: 78978}
    },
    {
      firstName: 'Pavan',
      middleName: 'Pothuraju',
      lastName: 'Kuar',
      maidenName: 'd;sfjg',
      ssnNumber: '214587147',
      alias: 'tikkodu',
      emailId: 'pavankuar@gail.com',
      employeeId: 3,
      agency: [{agencyName:'Caprock', agencyId: 1}],
      discipline: {disciplineValue:'Villain', disciplineId: 565},
      dateOfBirth: new Date(),
      address : {addressLine1: '787/gf', addressLine2: 'Karapakkam', city: 'Chennai', state: 'VN', country: 'canada', zip: 45612}
    },
    {
      firstName: 'John',
      middleName: 'Henry',
      lastName: 'Doe',
      ssnNumber: '8757842',
      maidenName: 'asdfasd',
      alias: 'jh',
      emailId: 'johndoe@gmail.com',
      employeeId: 4,
      agency: [{agencyName:'Caprock', agencyId: 1}],
      discipline: {disciplineValue:'Super-Villain', disciplineId: 787},
      dateOfBirth: new Date(),
      address : {addressLine1: 'asd/123', addressLine2: 'v.cmn.a', city: 'Puducherry', state: 'MH', country: 'Australia', zip: 139897}
    },
    {
      firstName: 'Milton',
      middleName: 'Bascon',
      lastName: 'Henry',
      maidenName: 'qwer',
      alias: 'bully',
      ssnNumber: '987135412',
      emailId: 'henrymilton@gmail.com',
      employeeId: 5,
      agency: [{agencyName:'Caprock', agencyId: 1}],
      discipline: {disciplineValue:'Villian', disciplineId: 565},
      dateOfBirth: new Date(),
      address : {addressLine1: 'qwefd4/467', addressLine2: 'Shollingnallur', city: 'Madurai', state: 'KL', country: 'Africa', zip: 12345}
    }     
  ];   */ 
  employeesBackup = [];
  employeeQuery: '';
  isEdit = false;
  currentEmployee;
  selected = [];

  onSelect({ selected }) {
    //console.log('Select Event', selected, this.selected);
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  ssnAppend(event) {
    let value = event.target.value;
    if (value.length === 3) {
      value = value + '-';
      this.editEmployeeForm.patchValue({ssnNumber: value});
    } else if (value.length === 6) {
      value = value + '-';
      this.editEmployeeForm.patchValue({ssnNumber: value});
    }
  }

  selectRow(event, row) {
    if (event.checked) {
      row.isSelected = true;
      this.selected = [...this.selected, row];
    } else {
      row.isSelected = false;
      this.selected = this.selected.filter(item => item.isSelected);
    }
    // console.log(this.selected)
  }


  constructor(private formBuilder: FormBuilder, private apiService: ApiService, private snackBar: MatSnackBar, public dialog: MatDialog) { }

  ngOnInit() {

    this.currentAgencyName = localStorage.getItem('accrAgencyName');
    //this.fetchAgencyList();
    this.fetchDesignationList();
    this.editEmployeeForm = this.formBuilder.group({
      ssnNumber: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(12),
        Validators.pattern(new RegExp('^[0-9]{3}\-?[0-9]{2}\-?[0-9]{4}$'))
      ])],
      firstName: ['', Validators.required],
      middleName: [''],
      maidenName: [''],
      alias: [''],
      agencyId: [''],
      designationId: ['', Validators.required],
      lastName: ['', Validators.required],
      // emailId: ['', Validators.email],
      emailId: ['', Validators.compose([
        Validators.email,
        Validators.pattern(new RegExp('\.com'))
      ])],
      dateOfBirth: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      rcity: ['', Validators.required],
      rstate: ['', Validators.required],
      rzipCode: ['', Validators.compose([
        Validators.required,
        Validators.maxLength(5),
        Validators.pattern(new RegExp('^[0-9]*$'))
      ])],
      rcountry: ['', Validators.compose([
        //Validators.required,
        Validators.pattern(new RegExp('^[a-zA-Z]*$'))
      ])],
      /*    agencyId: ['', Validators.required],
         designationId: ['', Validators.required], */
    });
    this.fetchEmployees();
    this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
  }

  fetchEmployees() {
    const loginId = localStorage.getItem('accrLoginId');
    const sub = this.apiService.fetchEmployeeList(loginId).subscribe(data => {
      const response: any = data;
      let employees = [];
      if (response.length) {
        employees = response.filter(item => item.active === 'S');
        this.employees = employees;
        this.employees = [...this.employees];
        this.employeesBackup = JSON.parse(JSON.stringify(this.employees));
      } else {
        this.employees = [];
        this.employeesBackup = [];
      }
    }, (error) => {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
    }, () => {
      console.log('employee fetch complete');

    });
  }

  searchEmployee() {
    if (this.employeeQuery === '') {
      this.employees = [...this.employeesBackup];
    } else {
      const arrayToReturn = this.employeesBackup.filter(row => {
        const columns = ['firstName', 'lastName', 'emailId', 'middleName', 'maidenName', 'ssnNumber', 'agencyName'];
        return (columns.map(column => {
          return row[column];
        }).toString().toLowerCase().indexOf(this.employeeQuery.toString().toLowerCase())) > -1;
      });
      this.employees = arrayToReturn;
    }
  }

  editEmployee(employee) {
    // console.log(employee);
    this.isEdit = true;
    this.currentEmployee = employee;
    let modifiedSsn = String(this.currentEmployee.ssnNumber);
    modifiedSsn = modifiedSsn.substring(0, 3) + '-' + modifiedSsn.substring(3, 5) + '-' + modifiedSsn.substring(5);
    this.editEmployeeForm = this.formBuilder.group({
      ssnNumber: [modifiedSsn, Validators.compose([
        Validators.required,
        Validators.maxLength(12),
        Validators.pattern(new RegExp('^[0-9]{3}\-?[0-9]{2}\-?[0-9]{4}$'))
      ])],
      firstName: [this.currentEmployee.firstName, Validators.required],
      middleName: this.currentEmployee.middleName,
      maidenName: this.currentEmployee.maidenName,
      lastName: [this.currentEmployee.lastName, Validators.required],
      alias: [this.currentEmployee.aliasSpecific],
      // agencyId: [this.currentEmployee.agency.length ? this.currentEmployee.agency[0].agencyId : ""],
      agencyId: [{ value: localStorage.getItem('accrAgencyName'), disabled: true }],
      designationId: [this.currentEmployee.discipline ? this.currentEmployee.discipline.disciplineId : ""],
      emailId: [this.currentEmployee.emailId, Validators.compose([
        Validators.email,
        Validators.pattern(new RegExp('\.com'))
      ])],
      dateOfBirth: [this.currentEmployee.dateOfBirth, Validators.required],
      addressLine1: [this.currentEmployee.address.addressLine1, Validators.required],
      addressLine2: [this.currentEmployee.address.addressLine2],
      rcity: [this.currentEmployee.address.city, Validators.required],
      rstate: [this.currentEmployee.address.state, Validators.required],
      rzipCode: [this.currentEmployee.address.zip, Validators.required],
      rcountry: [this.currentEmployee.address.country,  Validators.compose([
       // Validators.required,
        Validators.pattern(new RegExp('^[a-zA-Z]*$'))
      ])]
    });
    //  this.agencyId = this.currentEmployee.agency.length ? this.currentEmployee.agency[0].agencyId : "";
    this.agencyId = localStorage.getItem('accrAgencyName');
    this.designationId = this.currentEmployee.discipline ? this.currentEmployee.discipline.disciplineId : "";
    this.employees = [...this.employees];
    
  }

  deleteEmployee(employee) {
    const { employeeId } = employee;
    const requestBody = { employeeId };
    this.showSpinner = true;
    const loginId = localStorage.getItem('accrLoginId');
    const sub = this.apiService.deleteEmployee(employeeId, loginId).subscribe(data => {
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar(response.message, 'successSnackbar');
        this.fetchEmployees();
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      }
      this.showSpinner = false;
      this.isEdit = false;
    }, (error) => {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
      this.isEdit = false;
    }, () => {
      console.log('employee delete complete');
    });

  }

  saveEditing() {
    //console.log(this.editEmployeeForm.value);
    this.createEmployee();
  }

  openSnackBar(message, className) {
    this.snackBar.open(message, null, { duration: 5000, panelClass: [className], horizontalPosition: 'right', verticalPosition: 'top' });
  }

  cancelEditing() {
    this.isEdit = false;
    this.employees = [...this.employees];
  }

  createEmployee() {
    //   console.log(this.editEmployeeForm);
    this.employees = [...this.employees];
    const requestBody = { ...this.editEmployeeForm.value, employeeId: this.currentEmployee.employeeId };
    // requestBody.agency = [{agencyId: this.currentEmployee.agency.length ? this.currentEmployee.agency[0].agencyId : 0}];
    //  requestBody.agency = [{agencyId: 1}];
    requestBody.discipline = { disciplineId: this.currentEmployee.discipline.disciplineId, disciplineValue: this.designationList.filter(item => item.disciplineId === this.designationId)[0].disciplineValue };
    requestBody.aliasSpecific = this.editEmployeeForm.value.alias;
    requestBody.address = {
      addressId: this.currentEmployee.address.addressId,
      addressLine1: this.editEmployeeForm.value.addressLine1,
      addressLine2: this.editEmployeeForm.value.addressLine2,
      city: this.editEmployeeForm.value.rcity,
      state: this.editEmployeeForm.value.rstate,
      country: this.editEmployeeForm.value.rcountry,
      zip: Number(this.editEmployeeForm.value.rzipCode),
    };
    console.log(requestBody, 'requestBody1');
    delete requestBody.addressLine1;
    delete requestBody.addressLine2;
    delete requestBody.rcity;
    delete requestBody.rstate;
    delete requestBody.rcountry;
    delete requestBody.rzipCode;
    delete requestBody.agencyId;
    delete requestBody.designationId;
    this.showSpinner = true;
    console.log(requestBody, 'requestBody');
    const loginId = localStorage.getItem('accrLoginId');
    const sub = this.apiService.updateEmployee(requestBody, loginId).subscribe(data => {
      // console.log(data);
      const response: any = data;
      if (response.code === 1) {
        this.openSnackBar('Employee updated successfully', 'successSnackbar');
        this.fetchEmployees();
        this.isEdit = false;
        this.employees = [...this.employees];
      } else if (response.code === 0) {
        this.openSnackBar('Employee update failed', 'errorSnackbar');
      }
      this.showSpinner = false;
    }, (error) => {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('create employee success');
      this.isEdit = false;
      this.employees = [...this.employees];
    });
  }

  openDialog(row): void {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '350px',
      minHeight: '150px',
      data: { ...row }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.deleteEmployee(row);
      }
    });
  }

  agencyChange(event) {
    this.currentEmployee.agency = [{ agencyId: event }];
    this.agencyId = event;
  }

  designationChange(event) {
    this.currentEmployee.discipline = { disciplineId: event };
    this.designationId = event;
  }

  submitBg() {
    this.isSubmitDisabled = true;
    const sub = this.apiService.submitBg().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.isSubmitDisabled = false;
      if (response.code === 1) {
        this.openSnackBar(response.message, 'successSnackbar');
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      } else if (response.code === 2) {
        this.openSnackBar(response.message, 'warningSnackbar');
      }
    }, (error) => {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
      this.isSubmitDisabled = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
      this.isSubmitDisabled = false;

    });
  }

  fetchAgencyList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchAgencyList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.agencyList = response;
    }, (error) => {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  fetchDesignationList() {
    this.showSpinner = true;
    const sub = this.apiService.fetchDesignationList().subscribe(data => {
      console.log(data);
      const response: any = data;
      this.showSpinner = false;
      this.designationList = response;
    }, (error) => {
      console.log(error);
      this.openSnackBar(error.error.message, 'errorSnackbar');
      this.showSpinner = false;
    }, () => {
      console.log('agency fetch success');
      this.showSpinner = false;
    });
  }

  submitSpecific(employee) {
    console.log(employee, 'employee');
    this.employees = this.employees.map(item => {
      if (item.employeeId === employee.employeeId) {
        item['isSubmit'] = true;
      }
      return item;
    });
    const sub = this.apiService.submitSpecificBg(employee.employeeId).subscribe(data => {
      console.log(data);
      const response: any = data;
      this.employees = this.employees.map(item => {
        if (item.employeeId === employee.employeeId) {
          item['isSubmit'] = false;
        }
        return item;
      });
      if (response.code === 1) {
        this.openSnackBar(response.message, 'successSnackbar');
      } else if (response.code === 0) {
        this.openSnackBar(response.message, 'errorSnackbar');
      } else if (response.code === 2) {
        this.openSnackBar(response.message, 'warningSnackbar');
      }
    }, (error) => {
      console.log(error);
      this.employees = this.employees.map(item => {
        if (item.employeeId === employee.employeeId) {
          item['isSubmit'] = false;
        }
        return item;
      });
      this.openSnackBar(error.error.message, 'errorSnackbar');
    }, () => {
      console.log('agency fetch success');
      this.employees = this.employees.map(item => {
        if (item.employeeId === employee.employeeId) {
          item['isSubmit'] = false;
        }
        return item;
      });
    });
  }

}


@Component({
  selector: 'dialog-overview-example-dialog',
  template: `
  <div style="display:flex;justify-content:center;align-items:center;flex-direction:column">
  <h1 mat-dialog-title>Delete Confirmation</h1>
  <div mat-dialog-content>
    <p>Are you sure to delete the user?</p>
  </div>
  <div mat-dialog-actions>
    <button mat-button (click)="onNoClick()">Cancel</button>
    <button mat-button [mat-dialog-close]="true">Delete</button>
  </div>
  </div>
  `,
})

export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}