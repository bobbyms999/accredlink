import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { PreEmploymentScreeningRoutingModule } from './pre-employment-screeing-routing.module';
import { LandingComponent } from './landing/landing.component';
import { ManageEmployeeComponent } from './manage-employee/manage-employee.component';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatButtonModule} from '@angular/material/button';
import {MatGridListModule} from '@angular/material/grid-list';
import { UploadEmployeeComponent } from './upload-employee/upload-employee.component';
import { UploadStaticAliasComponent } from './upload-static-alias/upload-static-alias.component';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatDialogModule} from '@angular/material/dialog';
import { DialogOverviewExampleDialog } from './manage-employee/manage-employee.component';
import {MatSelectModule} from '@angular/material/select';
import { ViewBgComponent, ViewProofDialog } from './view-bg/view-bg.component';
import { TextMaskModule } from 'angular2-text-mask';
import {MatListModule} from '@angular/material/list';
import {MatDividerModule} from '@angular/material/divider';
import { NgxImageZoomModule } from 'ngx-image-zoom';
@NgModule({
  declarations: [CreateEmployeeComponent, LandingComponent, ManageEmployeeComponent, UploadEmployeeComponent, UploadStaticAliasComponent, DialogOverviewExampleDialog, ViewBgComponent, ViewProofDialog],
  imports: [
    CommonModule,
    PreEmploymentScreeningRoutingModule,
    MatCardModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatGridListModule,
    MatSnackBarModule,
    MatProgressBarModule,
    NgxDatatableModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    MatSelectModule,
    TextMaskModule,
    MatListModule,
    MatDividerModule,
    NgxImageZoomModule.forRoot() ,
  ],
  entryComponents: [DialogOverviewExampleDialog, ViewProofDialog]
})
export class PreEmploymentScreeningModule { }
