import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { LandingComponent } from './landing/landing.component';
import { ManageEmployeeComponent } from './manage-employee/manage-employee.component';
import { UploadEmployeeComponent } from './upload-employee/upload-employee.component';
import { UploadStaticAliasComponent } from './upload-static-alias/upload-static-alias.component';
import { ViewBgComponent } from './view-bg/view-bg.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'pmlanding' },
  { path: 'pmlanding', component: LandingComponent, children: [
    { path: '', component: ManageEmployeeComponent },
    { path: 'createEmployee', component: CreateEmployeeComponent },
  { path: 'manageEmployee', component: ManageEmployeeComponent },
  { path: 'uploadAlias', component: UploadStaticAliasComponent },
  { path: 'uploadEmployee', component: UploadEmployeeComponent },
  { path: 'viewBg', component: ViewBgComponent }
  ] }
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PreEmploymentScreeningRoutingModule { }
