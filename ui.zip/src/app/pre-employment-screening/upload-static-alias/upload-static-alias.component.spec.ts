import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadStaticAliasComponent } from './upload-static-alias.component';

describe('UploadStaticAliasComponent', () => {
  let component: UploadStaticAliasComponent;
  let fixture: ComponentFixture<UploadStaticAliasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadStaticAliasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadStaticAliasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
