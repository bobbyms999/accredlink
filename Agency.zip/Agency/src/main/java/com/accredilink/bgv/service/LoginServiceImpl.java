package com.accredilink.bgv.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.accredilink.bgv.entity.User;
import com.accredilink.bgv.exception.AccredLinkAppException;
import com.accredilink.bgv.pojo.Login;
import com.accredilink.bgv.repository.UserRepository;
import com.accredilink.bgv.util.PasswordEncrAndDecrUtil;
import com.accredilink.bgv.util.ResponseObject;
import com.accredilink.bgv.util.TokenGeneratorUtil;

public class LoginServiceImpl implements LoginService{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private NotificationService notificationService;
	
	private static final Logger logger = LoggerFactory.getLogger(RegistrationServiceImpl.class);
	private static StringBuffer emailBody = new StringBuffer(
			"You have requested to reset your password please click in the below link \n http://localhost:4200/resetPassword?token=");
	
	@Override
	public ResponseObject login(Login login) {
		Optional<User> optionalRegistration = userRepository.findByEmailIdOrUserName(login.getEmailId(),
				login.getEmailId());
		if (optionalRegistration.isPresent()) {
			if (PasswordEncrAndDecrUtil.check(login.getPassword(), optionalRegistration.get().getPassword())) {
				return ResponseObject.constructResponse("", 1, "");
			} else {
				throw new AccredLinkAppException("");
			}
		} else {
			throw new AccredLinkAppException("");
		}
	}

	@Override
	public ResponseObject forgot(Login login) {
		User user = null;
		String token = null;
		boolean flag = false;
		Optional<User> optionalRegistration = userRepository.findByEmailId(login.getEmailId());
		if (optionalRegistration.isPresent()) {
			user = optionalRegistration.get();
			token = TokenGeneratorUtil.generateNewToken();
			user.setTokenNumer(token);
			userRepository.save(user);
			emailBody = emailBody.append(token).append("&").append("email=" + login.getEmailId());
			flag = notificationService.sendEmail(login.getEmailId(), "Accredilink Reset Password",
					emailBody.toString());
			if (flag) {
				return ResponseObject.constructResponse("", 1);
			}
		} else {
			throw new AccredLinkAppException("Email Id Is not correct");
		}
		return ResponseObject.constructResponse("", 0);
	}

	@Override
	public ResponseObject reset(Login login) {
		// TODO Auto-generated method stub
		return null;
	}

}
