package com.accredilink.bgv.service;

import java.util.List;

import com.accredilink.bgv.entity.Employee;

public interface SearchService {
	
	public List<Employee> searchEmployee();

}
