package com.accredilink.bgv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.accredilink.bgv.exception.AccredLinkAppException;

@SpringBootApplication
@EnableJpaAuditing
public class App {

	public static void main(String[] args) {
		//SpringApplication.run(App.class, args);
		new App().m2();

	}

	public void m2() {
		try {
			new App().m1();
		} catch (Exception e) {
			System.out.println("2");
			System.out.println(e.getLocalizedMessage());
		}
	}

	public void m1() {
		try {
			throw new AccredLinkAppException("shshjs");
		} catch (Exception e) {
			System.out.println("1");
			System.out.println(e.getLocalizedMessage());
			//throw new AccredLinkAppException("msg");
		}
	}

}
